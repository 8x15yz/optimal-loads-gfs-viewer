#!/usr/bin/env python3
"""
Download all latest marine weather data from Optimal Loads API.
Usage:
    python download_latest.py                          # download everything
    python download_latest.py --vars HTSGW WDIR        # select variables
    python download_latest.py --save-json latest.json  # save JSON, then download
    python download_latest.py --from-json latest.json  # download from saved JSON (offline)
"""

import requests
import json
import os
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone


API_URL = "http://weather-api.bmap.kr/api/latest"

_W = 62


def _now_str() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sep(char: str = "─") -> str:
    return char * _W


def _banner(title: str) -> str:
    inner = _W - 2
    pad_l = (inner - len(title)) // 2
    pad_r = inner - len(title) - pad_l
    return (
        f"┌{'─' * inner}┐\n"
        f"│{' ' * pad_l}{title}{' ' * pad_r}│\n"
        f"└{'─' * inner}┘"
    )


def _bar(done: int, total: int, width: int = 24) -> str:
    if total == 0:
        return "░" * width
    filled = int(done / total * width)
    return "█" * filled + "░" * (width - filled)


def download_file(item: dict, save_dir: str) -> tuple[str, bool, str]:
    href = item["href"]
    s3_key = item["s3_key"]
    filename = os.path.basename(s3_key)
    save_path = os.path.join(save_dir, filename)

    try:
        r = requests.get(href, stream=True, timeout=60)
        r.raise_for_status()
        with open(save_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                f.write(chunk)
        size_kb = os.path.getsize(save_path) / 1024
        return s3_key, True, f"{size_kb:.0f} KB"
    except Exception as e:
        return s3_key, False, str(e)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vars", nargs="+", metavar="VAR")
    parser.add_argument("--save-json", metavar="PATH")
    parser.add_argument("--from-json", metavar="PATH")
    parser.add_argument("--out-dir", default="./weather_data")
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()

    print()
    print(_banner("Marine Weather Data Downloader"))
    print()

    # ── 1. Load JSON ─────────────────────────────────────────────────
    if args.from_json:
        print(f"  [1/3] Loading from JSON")
        print(f"        path      : {args.from_json}")
        with open(args.from_json, "r") as f:
            data = json.load(f)
    else:
        print(f"  [1/3] Requesting API")
        print(f"        url       : {API_URL}")
        r = requests.get(API_URL, timeout=30)
        r.raise_for_status()
        data = r.json()

    issued = data["issued"]
    print(f"        generated : {issued['generated_at']}")
    print(f"        expires   : {issued['expires_at']}")

    if args.save_json:
        with open(args.save_json, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"        saved     → {args.save_json}")

    # ── 2. Prepare log file ──────────────────────────────────────────
    os.makedirs(args.out_dir, exist_ok=True)
    log_ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(args.out_dir, f"download_{log_ts}.txt")
    log = open(log_path, "w", encoding="utf-8")

    def wlog(line: str = ""):
        log.write(line + "\n")

    wlog(f"Generated at : {issued['generated_at']}")
    wlog(f"Expires at   : {issued['expires_at']}")
    wlog(f"Total files  : {data['summary']['total_files']}")
    wlog(f"Variables    : {', '.join(data['summary']['variables_included'])}")
    wlog()

    var_meta = data.get("variables", {})
    if var_meta:
        wlog("=" * 60)
        wlog("Variable Descriptions")
        wlog("=" * 60)
        for vname, vmeta in var_meta.items():
            wlog()
            wlog(f"[{vname}]")
            wlog(f"  Name      : {vmeta.get('name_en', '')}")
            wlog(f"  Unit      : {vmeta.get('unit', '')}")
            wlog(f"  Direction : {vmeta.get('direction') or '-'}")
            wlog(f"  Source    : {vmeta.get('source', '')}")
            wlog(f"  Desc      : {vmeta.get('description', '')}")
        wlog()
        wlog("=" * 60)
    wlog()

    # ── 3. Per-variable summary ──────────────────────────────────────
    target_vars = args.vars if args.vars else list(data["assets"].keys())
    tasks: list[tuple[dict, str]] = []

    C_VAR, C_NAME, C_UNIT, C_SRC = 18, 26, 8, 12

    print()
    print(f"  [2/3] Variables to download")
    print()
    print(
        f"        {'VAR':<{C_VAR}}  {'Name':<{C_NAME}}  {'Unit':<{C_UNIT}}  {'Source':<{C_SRC}}  {'Files':>5}"
    )
    print(
        f"        {'─' * C_VAR}  {'─' * C_NAME}  {'─' * C_UNIT}  {'─' * C_SRC}  {'─' * 5}"
    )

    for var_name in target_vars:
        if var_name not in data["assets"]:
            print(f"        [SKIP] {var_name} — unknown variable")
            wlog(f"[SKIP] {var_name} — unknown variable")
            continue

        var_data = data["assets"][var_name]
        meta     = var_meta.get(var_name, {})
        name_en  = meta.get("name_en", "")
        unit     = meta.get("unit", "")
        source   = meta.get("source", "")

        var_dir = os.path.join(args.out_dir, var_name)
        os.makedirs(var_dir, exist_ok=True)

        for step in var_data["steps"]:
            tasks.append((step, var_dir))

        print(
            f"        {var_name:<{C_VAR}}  {name_en:<{C_NAME}}  {unit:<{C_UNIT}}  {source:<{C_SRC}}  {var_data['file_count']:>5}"
        )
        wlog(f"  {var_name:<{C_VAR}}  {name_en:<{C_NAME}}  {unit:<{C_UNIT}}  {source:<{C_SRC}}  {var_data['file_count']:>3} files")

    total = len(tasks)
    print(
        f"        {'─' * C_VAR}  {'─' * C_NAME}  {'─' * C_UNIT}  {'─' * C_SRC}  {'─' * 5}"
    )
    print(
        f"        {'Total':<{C_VAR}}  {'':>{C_NAME}}  {'':>{C_UNIT}}  {'':>{C_SRC}}  {total:>5}"
    )

    # ── 4. Parallel download ─────────────────────────────────────────
    print()
    print(f"  [3/3] Downloading  {total} files  ({args.workers} concurrent)")
    print()
    wlog()
    wlog(f"Starting {total} downloads ({args.workers} concurrent)")
    wlog("-" * 60)

    success, failed = 0, 0
    fails: list[tuple[str, str]] = []
    n_width = len(str(total))

    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {
            executor.submit(download_file, step, save_dir): step["s3_key"]
            for step, save_dir in tasks
        }

        for future in as_completed(futures):
            s3_key, ok, msg = future.result()
            filename = os.path.basename(s3_key)
            done = success + failed + 1

            if ok:
                success += 1
                wlog(f"[OK]   {filename}  ({msg})")
            else:
                failed += 1
                fails.append((filename, msg))
                wlog(f"[FAIL] {filename}  — {msg}")

            bar = _bar(done, total)
            pct = done / total * 100
            print(
                f"\r        [{bar}] {pct:>5.1f}%"
                f"  {done:>{n_width}}/{total}"
                f"  ok {success}  fail {failed}  ",
                end="",
                flush=True,
            )

    print()  # newline after progress bar

    # ── 5. Final summary ─────────────────────────────────────────────
    wlog("-" * 60)
    wlog(f"Done: ok {success} / failed {failed} / total {total}")
    if fails:
        wlog()
        wlog("[Failure list]")
        for fname, err in fails:
            wlog(f"  {fname}  — {err}")
    log.close()

    print()
    print(f"  {_sep()}")
    if not fails:
        print(f"  Result  :  ok {success} / total {total}  — all done")
    else:
        print(f"  Result  :  ok {success} / failed {failed} / total {total}  — completed with errors")
        print()
        print(f"  Failed files:")
        for fname, err in fails:
            print(f"    x  {fname}")
            print(f"       {err}")
    print()
    print(f"  Log     → {log_path}")
    print(f"  {_sep()}")
    print()


if __name__ == "__main__":
    main()
